import csv
import json
from collections import Counter
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
import sys

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
PROJECT = WORKSPACE / "C\u4ee3\u7801" / "C\u9898\u5de5\u4f5c\u533a"
DATA = WORKSPACE / "C\u6838\u67e5" / "v1"
sys.path.insert(0, str(PROJECT / "scripts"))
import experiment_q1_gated_mlp as residual
import experiment_q1_motion_gates as gates

HORIZONS = (.2, .6, 1.)

def read(path):
    with path.open(newline="", encoding="utf-8-sig") as f:
        yield from csv.DictReader(f)

def write(path, fields, rows):
    with path.open("w", newline="", encoding="utf-8") as f:
        out = csv.writer(f)
        out.writerow(fields)
        out.writerows(rows)

windows, queries, reference = [], [], []
for rec in read(DATA / "record_index.csv"):
    split = rec["split"]
    if split not in {"train", "test"}:
        continue
    uid = rec["episode_uuid"]
    with np.load(DATA / "records" / f"{uid}.npz", allow_pickle=False) as arrays:
        for side in ("left_hand", "right_hand"):
            t = arrays[side + "__t_s"]
            xyz = arrays[side + "__position"].mean(axis=1)
            valid = arrays[side + "__reference_candidate"]
            frame_s = float(np.median(np.diff(t)))
            eps = 1e-9
            assert frame_s > 0
            for grid in np.arange(t[0]+.2, t[-1]+eps, 2.):
                anchor = int(np.searchsorted(t, grid+eps, side="right"))-1
                first = anchor+1
                begin = int(np.searchsorted(t, t[anchor]-.2-eps, side="left"))
                end = int(np.searchsorted(t, t[anchor]+1.+eps, side="right"))
                if anchor-begin < 1 or end <= first:
                    continue
                if t[anchor]-t[begin] < .2-frame_s-eps or t[end-1]-t[anchor] < 1.-frame_s-eps:
                    continue
                if not valid[begin:end].all() or (np.diff(t[begin:end]) > 3*frame_s+eps).any():
                    continue
                if t[first]-t[anchor] > .2+eps:
                    continue
                window = f"{uid}_{side}_{anchor}"
                windows.append((window,uid,rec["dataset"],rec["environment_id"],split,side,
                                begin,first,end,grid,t[anchor]))
                for i in range(first,end):
                    queries.append((window,i,t[i],t[i]-t[anchor]))
                    if split == "test":
                        reference.append((window,i,t[i]-t[anchor],*xyz[i]))

window_fields = ("window_id","episode_uuid","dataset","environment_id","split","side",
                 "history_start","start_index","end_index_exclusive","grid_s","anchor_s")
assert len({w[0] for w in windows}) == len(windows)
assert len({w[1] for w in windows if w[4]=="train"}) == 55
assert len({w[1] for w in windows if w[4]=="test"}) == 7
assert not ({w[3] for w in windows if w[4]=="train"} & {w[3] for w in windows if w[4]=="test"})
write(ROOT/"data"/"windows.csv",window_fields,windows)
write(ROOT/"queries.csv",("window_id","frame_index","timestamp_s","age_from_anchor_s"),queries)
write(ROOT/"test_reference.csv",("window_id","frame_index","age_from_anchor_s","x","y","z"),reference)

# Reuse both existing model implementations with the same anchor-based horizons.
residual.BASE = ROOT
train = residual.collect(DATA, "train")
test = residual.collect(DATA, "test")
for row in train + test:
    row["limits"] = np.searchsorted(row["age"], np.array(HORIZONS)+1e-9, side="right")
    assert (row["limits"] > 0).all()
gates.prepare_experts(train)
gates.prepare_experts(test)
models = gates.fit_models(train)
gate_rows = gates.evaluate_models(models,test,"official_test",include_oracle=False)
residual_rows, _ = residual.evaluate(train,test,"official_test")
gate_ade = {(r["window_id"],r["horizon_s"]):r["ade"] for r in gate_rows if r["method"]=="mlp_gate"}
residual_ade = {(r["window_id"],r["horizon_s"]):r["candidate_ade"] for r in residual_rows}
assert gate_ade.keys() == residual_ade.keys()
assert len(gate_ade) == 3*len(test)
write(ROOT/"local_test_ade.csv",("window_id","horizon_s","mlp_gate_ade","conditional_residual_mlp_ade"),
      [(key[0],key[1],value,residual_ade[key]) for key,value in gate_ade.items()])
scales = {source:float(np.median([r["excursion"] for r in train if r["meta"]["dataset"]==source]))
          for source in sorted({r["meta"]["dataset"] for r in train})}
assert all(value>0 for value in scales.values())
counts = Counter((w[4],w[2]) for w in windows)
protocol = {"windows":{f"{split}/{source}": count for (split,source),count in sorted(counts.items())},
            "test_frames":len(reference),"scale_by_source_training_only":scales}
(ROOT/"summary.json").write_text(json.dumps(protocol,indent=2)+"\n",encoding="utf-8")
with ZipFile(ROOT/"neutral_inputs.zip","w",ZIP_DEFLATED) as bundle:
    for name in ("data/windows.csv","queries.csv","README.md"):
        bundle.write(ROOT/name,"windows.csv" if name=="data/windows.csv" else name)
with ZipFile(ROOT/"neutral_inputs.zip") as bundle:
    assert bundle.testzip() is None
print(json.dumps(protocol,indent=2))
