"""Score complete test predictions against the frozen neutral-window protocol."""
import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent

def rows(path):
    with path.open(newline="", encoding="utf-8-sig") as file:
        yield from csv.DictReader(file)

def collapse(table, axis):
    parent = defaultdict(list)
    for key, values in table.items():
        parent[key[:axis] + key[axis+1:]].append(mean(values))
    return parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("predictions", nargs="?", type=Path)
    args = parser.parse_args()
    manifest = {row["window_id"]: row for row in rows(ROOT/"data"/"windows.csv") if row["split"]=="test"}
    scales = json.loads((ROOT/"summary.json").read_text())["scale_by_source_training_only"]
    errors = defaultdict(list)
    if args.predictions:
        predictions = {}
        for row in rows(args.predictions):
            key = (row["window_id"], int(row["frame_index"]))
            point = tuple(float(row[axis]) for axis in "xyz")
            if key in predictions or not all(map(math.isfinite,point)):
                parser.error(f"Duplicate or invalid prediction: {key}")
            predictions[key] = point
        reference = {(row["window_id"],int(row["frame_index"])): row for row in rows(ROOT/"test_reference.csv")}
        if predictions.keys() != reference.keys():
            parser.error(f"{len(reference.keys()-predictions.keys())} missing frames, "
                         f"{len(predictions.keys()-reference.keys())} unexpected frames")
        for key, row in reference.items():
            actual = tuple(float(row[axis]) for axis in "xyz")
            errors[key[0]].append((float(row["age_from_anchor_s"]), math.dist(actual,predictions[key])))

    grouped = defaultdict(list)
    for row in rows(ROOT/"local_test_ade.csv"):
        window = row["window_id"]
        meta = manifest[window]
        horizon = float(row["horizon_s"])
        source = meta["dataset"]
        scores = {model:float(row[column]) for model,column in
                  (("MLP gate","mlp_gate_ade"),("conditional residual MLP","conditional_residual_mlp_ade"))}
        if args.predictions:
            scores["original kNN"] = mean(error for age,error in errors[window] if age <= horizon+1e-9)
        for model, ade in scores.items():
            key = (model,horizon,source,meta["environment_id"],meta["episode_uuid"])
            grouped[key].append(ade/scales[source])
    by_env = collapse(grouped,4)
    headline = collapse(collapse(collapse(by_env,3),2),1)
    report = {key[0]:mean(values) for key,values in headline.items()}
    print(json.dumps(report,indent=2))
    if args.predictions:
        for model in ("MLP gate","conditional residual MLP"):
            print(f"Original kNN vs {model}: {100*(1-report['original kNN']/report[model]):+.3f}% ADE reduction")
        for (model,horizon,source,env), values in sorted(by_env.items()):
            print(model,source,env,horizon,f"{mean(values):.6f}")

if __name__ == "__main__":
    main()
